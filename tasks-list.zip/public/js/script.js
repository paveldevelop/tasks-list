var clientbox = new Vue({
    el: '#tasks_list',
    data: {
		    	tasks: vue_data,
			
			checked: 'dec-checkbox-checked',

 			 unchecked: 'dec-checkbox',
			
			disabled_class:'disabled-task'
		},
		 
		methods:{
				
			fetchTaskList() {
	                		axios.get('/list').then((res) => {
	                   	 this.tasks = res.data;
				
	                })
		      .catch((err) => console.error(err));
			
			
	            },	
			 createTask() {
	                		axios.get('/add')
	                    	.then((res) => {
					this.fetchTaskList();
	                   	 })
	                    	.catch((err) => console.error(err));
				
				
	            },
		        updateStatus(task) {
				var status_num=task.status ? '0' : '1';
		                axios.get('/update_status/' + task.id +'/' + status_num)
		                    .then((res) => {
		                        this.fetchTaskList()
					
		                    })
		                    .catch((err) => console.error(err));
		            },	
			deleteTask(task) {
		                axios.get('/delete/' + task.id)
		                    .then((res) => {
		                       // this.fetchTaskList()
					var remIndex=this.tasks.indexOf(task);
					this.tasks.splice(remIndex,1);
		                    })
		                    .catch((err) => console.error(err));
		            },	
			getTotal(){
				return this.tasks.length;
			},
			getTotalDoneTasks(){
				 var total = 0;

			            this.tasks.forEach(function(task){
			                if (task.status){
			                    total++;
			                }
			            });

			           return total;
			},
			editNameTask(task){
				console.log(task.edit);
				task.edit=!task.edit;
				console.log(task.edit);
			},
			saveName(task){
			 
				axios.post('/update_name', { id: task.id, name: task.name })
				  .then(function(res){
				    task.edit=!task.edit;
				  })
				 .catch((err) => console.error(err)); 
			}	
		}
		
	});