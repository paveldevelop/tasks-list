<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>TASKS LIST</title>
	<link rel="stylesheet"  href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css"/>
	<link href="../../public/css/main.css" rel="stylesheet"/>
</head>
<body>
<div class="container text-center">
<h1 >Tasks List</h1>
<p >
server: laravel 4.2 <br>
client : vue.js , bootstrap , axios.js
 </p>
<pre >click on task name you can edit name of task</pre>
</div>
<div class="container" id="tasks_list"  v-cloak>
<div class="list-container">
<div class="list-header">משימות
<span class="glyphicon glyphicon-plus-sign" v-on:click="createTask()"></span>
</div>
<transition-group name="list-complete" tag="ul">


  <li class="list-group-item" v-for="(task,index) in tasks" v-bind:key="task.id" v-bind:class="[task.status ?  disabled_class: '']">
	
	<span v-bind:class="[task.status ?  checked : unchecked]"  v-on:click="updateStatus(task)"></span>
	{{index+1}} . 
	<span class="task-name" v-show="!task.edit" v-on:click="editNameTask(task)">{{task.name}}</span><input type="text"  v-model="task.name"  v-show="task.edit" maxlength="200" class="edit-input"><span class="glyphicon glyphicon-floppy-disk"  v-show="task.edit" v-on:click="saveName(task);"></span>
	<span class="glyphicon glyphicon-remove"  v-on:click="deleteTask(task)"></span>
  </li>


 </transition-group>
<div class="footer-total">
<div class="col-md-4 col-xs-4 text-center">לסיום: {{getTotal() - getTotalDoneTasks()}}</div>
<div class="col-md-4 col-xs-4  text-center">הושלמו: {{getTotalDoneTasks()}}</div>
<div class="col-md-4 col-xs-4  text-center">סה"כ : {{getTotal()}}</div>
</div>
</div>
	
	</div>
<script>
var vue_data=<?=$tasks?>;
</script>
<script src="../../public/js/axios.min.js"></script>

<script src="../../public/js/vue.min.js"></script>
<!--<script src="https://unpkg.com/vue"></script>-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/lodash.js/4.14.1/lodash.min.js"></script>
<script src="../../public/js/script.js"></script>
</body>
</html>
