<?php
 class Task extends Eloquent 
{
	protected $table='tasks';
	protected $primaryKey='id';
	protected $fillable=['name','status'];
	public $incrimenting=true;
	public $timestemps=true;
}
