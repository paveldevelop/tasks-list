<?php

class TasksController extends \BaseController {

	private function getAllTasks()
{
	$tasks=Task::latest()->get();
		//dd($tasks);
		$tasks_json=[];
		foreach($tasks as $key=>$task)
		{
			
			$tasks_json[$key]=array("name"=>$task->name,"id"=>$task->id,"status"=>$task->status,"edit"=>false);
		}
		
		return $tasks_json;

}
	public function getTasks()
	{
		 return View::make('tasks',array('tasks'=>json_encode(self::getAllTasks())));
		
	}

	public function getListTasks()
	{
		 return json_encode(self::getAllTasks());
		
	}
	
	public function addTask()
	{
		$task=new Task;
		$task->name="new task";
		//$task->status=1;
		$task->save();
	}





	public function updateTaskName()
	{
		$id=Input::get('id');
		$name=Input::get('name');
		$task=Task::find($id);
		$task->name=$name;
		$task->save();
	}
	public function updateTaskStatus($id,$status)
	{
		
		$task=Task::find($id);
		$task->status=$status;
		$task->save();
		
	}

	
	public function deleteTask($id)
	{
		//
		$task=Task::findOrFail($id);
		$task->delete();
		return 204;
		//Task::destroy($id);

		//$this->getTasks();

	}


}
